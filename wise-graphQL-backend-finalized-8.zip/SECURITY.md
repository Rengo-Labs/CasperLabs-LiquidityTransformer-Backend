# Security Policy

## Reporting a Vulnerability

If you find a security vulnerability, please send an email to *security@rengo.capital*.
