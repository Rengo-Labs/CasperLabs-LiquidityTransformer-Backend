export enum WISEEvents {
	SetFeeTo = "liquidity_set_fee_to",
	SetFeeToSetter = "liquidity_set_fee_to_setter",
	CreatePair = "liquidity_create_pair",
}
